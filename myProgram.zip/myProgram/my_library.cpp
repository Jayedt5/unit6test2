#include "my_library.h"

int addTwoInts(int a, int b)
{
  return a + b;
} 